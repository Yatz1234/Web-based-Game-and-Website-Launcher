// State
let items = [
  {
    id: '1',
    name: 'Steam',
    type: 'game',
    url: 'https://store.steampowered.com',
    appUrl: 'steam://',
    category: 'games',
    favorite: true,
    icon: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=800&auto=format&fit=crop&q=60',
  },
  {
    id: '2',
    name: 'Epic Games',
    type: 'game',
    url: 'https://store.epicgames.com',
    appUrl: 'com.epicgames.launcher://',
    category: 'games',
    favorite: false,
    icon: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=60',
  },
  {
    id: '3',
    name: 'GitHub',
    type: 'website',
    url: 'https://github.com',
    category: 'websites',
    favorite: true,
    icon: 'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=800&auto=format&fit=crop&q=60',
  }
];

let selectedCategory = 'all';
let searchQuery = '';

// Theme
function initTheme() {
  try {
    const theme = localStorage.getItem('launcher_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
  } catch (error) {
    console.error('Error loading theme:', error);
    document.documentElement.setAttribute('data-theme', 'dark');
  }
}

function toggleTheme() {
  try {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('launcher_theme', newTheme);
  } catch (error) {
    console.error('Error saving theme:', error);
  }
}

// Items Management
function addItem(newItem) {
  items.push({
    ...newItem,
    id: crypto.randomUUID(),
    favorite: false,
    lastUsed: null
  });
  saveItems();
  renderItems();
}

function deleteItem(id) {
  items = items.filter(item => item.id !== id);
  saveItems();
  renderItems();
}

function toggleFavorite(id) {
  items = items.map(item =>
    item.id === id ? { ...item, favorite: !item.favorite } : item
  );
  saveItems();
  renderItems();
}

function launchItem(item) {
  const now = new Date().toISOString(); // Store as ISO string for better serialization
  items = items.map(i =>
    i.id === item.id ? { ...i, lastUsed: now } : i
  );
  saveItems();

  if (item.appUrl) {
    window.location.href = item.appUrl;
  } else if (item.url) {
    window.open(item.url, '_blank');
  }
}

// Filtering
function getFilteredItems() {
  let filtered = items;

  if (selectedCategory === 'favorites') {
    filtered = filtered.filter(item => item.favorite);
  } else if (selectedCategory === 'recent') {
    filtered = filtered.filter(item => item.lastUsed)
      .sort((a, b) => new Date(b.lastUsed) - new Date(a.lastUsed));
  } else if (selectedCategory !== 'all') {
    filtered = filtered.filter(item => item.category === selectedCategory);
  }

  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    filtered = filtered.filter(item =>
      item.name.toLowerCase().includes(query)
    );
  }

  return filtered;
}

// Rendering
function renderGrid() {
  const grid = document.getElementById('grid');
  const filteredItems = getFilteredItems();

  grid.innerHTML = filteredItems.map(item => `
    <div class="card">
      <div class="card-image">
        <img src="${item.icon || 'https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=800&auto=format&fit=crop&q=60'}" alt="${item.name}">
        <button
          class="favorite-button ${item.favorite ? 'active' : ''}"
          onclick="toggleFavorite('${item.id}')"
        >
          <svg viewBox="0 0 24 24" width="20" height="20">
            <path fill="currentColor" d="M12 21.35l-1.9-1.72C5.4 15.36 2 12.27 2 8.5 2 5.41 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.08C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.1 11.13L12 21.35z"/>
          </svg>
        </button>
      </div>
      <div class="card-content">
        <h3 class="card-title">${item.name}</h3>
        <div class="card-footer">
          <span class="card-type">${item.type}</span>
          <button class="launch-button" onclick="launchItem(${JSON.stringify(item).replace(/"/g, '&quot;')})">
            Launch
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function renderManageList() {
  const itemsList = document.getElementById('itemsList');
  
  itemsList.innerHTML = items.map(item => `
    <div class="item">
      <div class="item-info">
        ${item.icon ? `
          <div class="item-image">
            <img src="${item.icon}" alt="${item.name}">
          </div>
        ` : ''}
        <div class="item-details">
          <h3>${item.name}</h3>
          <p>${item.type}</p>
        </div>
      </div>
      <button class="delete-button" onclick="deleteItem('${item.id}')">
        <svg viewBox="0 0 24 24" width="20" height="20">
          <path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
        </svg>
      </button>
    </div>
  `).join('');
}

function renderItems() {
  if (selectedCategory === 'manage') {
    document.getElementById('grid').classList.add('hidden');
    document.getElementById('manage').classList.remove('hidden');
    renderManageList();
  } else {
    document.getElementById('grid').classList.remove('hidden');
    document.getElementById('manage').classList.add('hidden');
    renderGrid();
  }
}

// Event Handlers
function handleCategoryClick(category) {
  selectedCategory = category;
  document.querySelectorAll('.categories button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.category === category);
  });
  renderItems();
}

function handleSearch(query) {
  searchQuery = query;
  renderItems();
}

function handleAddItem(e) {
  e.preventDefault();
  const formData = new FormData(e.target);
  const newItem = {
    name: formData.get('name'),
    type: formData.get('type'),
    url: formData.get('url'),
    appUrl: formData.get('appUrl'),
    icon: formData.get('icon'),
    category: formData.get('type') === 'game' ? 'games' : 'websites',
  };
  addItem(newItem);
  e.target.reset();
}

function handleTypeChange(e) {
  const gameUrlField = document.querySelector('.game-url');
  gameUrlField.classList.toggle('hidden', e.target.value !== 'game');
}

// Storage
function saveItems() {
  try {
    localStorage.setItem('launcher_items', JSON.stringify(items));
  } catch (error) {
    console.error('Error saving items:', error);
  }
}

function loadItems() {
  try {
    const savedItems = localStorage.getItem('launcher_items');
    if (savedItems) {
      items = JSON.parse(savedItems);
    }
  } catch (error) {
    console.error('Error loading items:', error);
    // En cas d'erreur, on garde les items par défaut
  }
}

// Initialization
function init() {
  initTheme();
  loadItems();

  // Event Listeners
  document.getElementById('themeToggle').addEventListener('click', toggleTheme);
  document.getElementById('search').addEventListener('input', e => handleSearch(e.target.value));
  document.getElementById('addItemForm').addEventListener('submit', handleAddItem);
  document.getElementById('type').addEventListener('change', handleTypeChange);
  
  document.querySelectorAll('.categories button').forEach(button => {
    button.addEventListener('click', () => handleCategoryClick(button.dataset.category));
  });

  renderItems();
}

init();